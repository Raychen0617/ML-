import numpy as np
import pandas as pd
import seaborn as sns
import csv
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import learning_curve
import matplotlib.pyplot as plt
from sklearn.naive_bayes import BernoulliNB

############    1. load data    #######################################################   
#df = pd.read_csv('agaricus-lepiota.data')
#df.to_csv('agaricus-lepiota.csv')

data = pd.read_csv("agaricus-lepiota.csv")
df = pd.DataFrame(data=data)
df.rename(columns={' ':' ','p': 'poisonous', 'x': 'cap-shape', 's': 'cap-surface', 'n': 'cap-color', 't': 'bruises?', 'p.1': 'odor', 'f': 'gill-attachment', 'c': 'gill-spacing', 'n.1': 'gill-size', 'k': 'gill-color', 'e': 'stalk-shape', 'e.1': 'stalk-root', 's.1': 'stalk-surface-above-ring', 's.2': 'stalk-surface-below-ring', 'w': 'stalk-color-above-ring', 'w.1': 'stalk-color-below-ring', 'p.2': 'veil-type', 'w.2': 'veil-color', 'o': 'ring-number', 'p.3': 'ring-type', 'k.1': 'spore-print-color', 's.3': 'population', 'u': 'habitat'}, inplace=True)
list(df)

##############  2.  draw distribution   #############################################
'''
sns.factorplot(x="cap-shape", data=df, kind="count")
sns.factorplot(x="cap-surface", data=df, kind="count")
sns.factorplot(x="cap-color", data=df, kind="count")
sns.factorplot(x="bruises?", data=df,  kind="count")
sns.factorplot(x="odor", data=df, kind="count")
sns.factorplot(x="gill-attachment", data=df,  kind="count")
sns.factorplot(x="gill-spacing", data=df,  kind="count")
sns.factorplot(x="gill-size", data=df,  kind="count")
sns.factorplot(x="gill-color", data=df,  kind="count")
sns.factorplot(x="stalk-shape", data=df,  kind="count")
sns.factorplot(x="stalk-root", data=df, kind="count")
sns.factorplot(x="stalk-surface-above-ring", data=df, kind="count")
sns.factorplot(x="stalk-surface-below-ring", data=df, kind="count")
sns.factorplot(x="stalk-color-above-ring", data=df, kind="count")
sns.factorplot(x="stalk-color-below-ring", data=df, kind="count")
sns.factorplot(x="veil-type", data=df, kind="count")
sns.factorplot(x="veil-color", data=df, kind="count")
sns.factorplot(x="ring-number", data=df, kind="count")
sns.factorplot(x="ring-type", data=df, kind="count")
sns.factorplot(x="spore-print-color", data=df,  kind="count")
sns.factorplot(x="population", data=df, kind="count")
sns.factorplot(x="habitat", data=df, kind="count")
plt.show()
'''

#################### 3-1 . Drop features with any missing value.   ##################################
df.dropna(axis='columns')
print(df)



################### 4   ######################################################

# string to float
#group = df.groupby(['poisonous', 'stalk-color-below-ring']).size()
#print(group)

e_total = df.loc[(df['poisonous'] == 'e')].count()[0]


color_list = ['n','b','c','g','o','p','e','w','y']
color_p_list = []
for color in color_list:
    x_conditional = df.loc[(df['poisonous'] == 'e') & (df['stalk-color-below-ring'] == color)].count()[0]
    y_conditional = df.loc[(df['poisonous'] == 'p') & (df['stalk-color-below-ring'] == color)].count()[0]
    c_p = x_conditional/e_total
    color_p_list.append(c_p)
    plt.plot(color, c_p,color='b')
print(e_total)
print(color_list)
print(color_p_list)

plt.plot(color_list, color_p_list)
plt.show()
