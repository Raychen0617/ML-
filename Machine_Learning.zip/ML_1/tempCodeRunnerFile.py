
arr = np.array(df['petal_length'])